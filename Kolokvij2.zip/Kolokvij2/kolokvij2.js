window.onload = function(){
    let ime = prompt ("Unesite vaše ime:")
    if(ime) {
    alert (`Vaše ime je :${ime} `) 
}
};